package com.example.notes

import android.app.Activity
import android.os.Bundle
import com.example.notes.ui.Navigator
import com.example.notes.ui.Theme

class MainActivity : Activity() {
    private lateinit var nav: Navigator

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Theme.primary
        Store.setup(applicationContext)

        nav = Navigator(this)
        nav.push(HomeScreen())
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (!nav.pop()) super.onBackPressed()
    }
}
