package com.example.notes.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.app.AlertDialog
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

// =====================================================================
//  Mini DSL de UI sobre as Views nativas do Android (sem dependências)
// =====================================================================

// ---------- Tema (troque as cores aqui) ----------
object Theme {
    var primary = Color.parseColor("#3F51B5")
    var onPrimary = Color.WHITE
    var background = Color.parseColor("#FAFAFA")
    var text = Color.parseColor("#212121")
    var textSecondary = Color.parseColor("#757575")
    var danger = Color.parseColor("#D32F2F")
    var divider = Color.parseColor("#E0E0E0")
}

// ---------- dp -> pixels ----------
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Int): Int = context.dp(v)

// ---------- Estado observável ----------
class State<T>(initial: T) {
    private val listeners = ArrayList<(T) -> Unit>()

    var value: T = initial
        set(v) {
            field = v
            for (l in ArrayList(listeners)) l(v)
        }

    /** Chama [fn] agora e a cada mudança. Retorna uma função para cancelar. */
    fun observe(fn: (T) -> Unit): () -> Unit {
        listeners.add(fn)
        fn(value)
        return { listeners.remove(fn) }
    }
}

// ---------- Base: adiciona uma view ao pai e configura ----------
fun <T : View> ViewGroup.add(view: T, block: T.() -> Unit = {}): T {
    addView(view)
    view.block()
    return view
}

// ---------- Ajustes de layout (chame dentro do bloco da view) ----------
fun <T : View> T.weight(w: Float): T {
    val lp = layoutParams as? LinearLayout.LayoutParams ?: return this
    lp.weight = w
    val horizontal = (parent as? LinearLayout)?.orientation == LinearLayout.HORIZONTAL
    if (horizontal) lp.width = 0 else lp.height = 0
    layoutParams = lp
    return this
}

fun <T : View> T.margin(l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): T {
    val lp = layoutParams as? ViewGroup.MarginLayoutParams ?: return this
    lp.setMargins(dp(l), dp(t), dp(r), dp(b))
    layoutParams = lp
    return this
}

// ---------- Contêineres ----------
/** Raiz de uma tela: coluna vertical com o fundo do tema. */
fun Context.page(block: LinearLayout.() -> Unit): LinearLayout {
    val root = LinearLayout(this)
    root.orientation = LinearLayout.VERTICAL
    root.setBackgroundColor(Theme.background)
    root.block()
    return root
}

fun ViewGroup.verticalLayout(block: LinearLayout.() -> Unit): LinearLayout =
    add(LinearLayout(context)) {
        orientation = LinearLayout.VERTICAL
        block()
    }

fun ViewGroup.row(block: LinearLayout.() -> Unit): LinearLayout =
    add(LinearLayout(context)) {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        block()
    }

/** Área de conteúdo com margem interna; ocupa o espaço que sobrar. */
fun ViewGroup.content(block: LinearLayout.() -> Unit): LinearLayout =
    add(LinearLayout(context)) {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        weight(1f)
        block()
    }

/** Coluna rolável; ocupa o espaço que sobrar. */
fun ViewGroup.scroll(block: LinearLayout.() -> Unit): ScrollView {
    val sv = add(ScrollView(context)) { weight(1f) }
    val inner = LinearLayout(context)
    inner.orientation = LinearLayout.VERTICAL
    sv.addView(inner)
    inner.block()
    return sv
}

// ---------- Widgets ----------
fun ViewGroup.text(
    value: String,
    size: Int = 16,
    bold: Boolean = false,
    color: Int = Theme.text,
    block: TextView.() -> Unit = {}
): TextView =
    add(TextView(context)) {
        text = value
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size.toFloat())
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        block()
    }

fun ViewGroup.input(
    hint: String = "",
    value: String = "",
    multiline: Boolean = false,
    onChange: (String) -> Unit = {}
): EditText {
    val e = EditText(context)
    e.hint = hint
    e.setText(value)
    var type = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    if (multiline) {
        type = type or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        e.minLines = 4
        e.gravity = Gravity.TOP or Gravity.START
    }
    e.inputType = type
    e.addTextChangedListener(object : TextWatcher {
        override fun afterTextChanged(s: Editable?) {
            onChange(s?.toString() ?: "")
        }
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
    })
    return add(e)
}

enum class ButtonKind { Primary, Secondary, Danger }

fun ViewGroup.button(
    label: String,
    kind: ButtonKind = ButtonKind.Primary,
    onClick: () -> Unit
): Button {
    val bgColor = when (kind) {
        ButtonKind.Primary -> Theme.primary
        ButtonKind.Secondary -> Theme.divider
        ButtonKind.Danger -> Theme.danger
    }
    val fgColor = if (kind == ButtonKind.Secondary) Theme.text else Theme.onPrimary
    return add(Button(context)) {
        text = label
        setTextColor(fgColor)
        setAllCaps(false)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        val shape = GradientDrawable()
        shape.cornerRadius = dp(8).toFloat()
        shape.setColor(bgColor)
        background = shape
        setOnClickListener { onClick() }
    }
}

fun ViewGroup.checkbox(
    label: String,
    checked: Boolean = false,
    onChange: (Boolean) -> Unit
): CheckBox =
    add(CheckBox(context)) {
        text = label
        isChecked = checked
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

fun ViewGroup.divider(): View =
    add(View(context)) {
        setBackgroundColor(Theme.divider)
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1))
    }

fun ViewGroup.spacer(heightDp: Int): View =
    add(View(context)) {
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(heightDp))
    }

/** Barra superior colorida, com botão de voltar opcional. */
fun ViewGroup.topBar(title: String, onBack: (() -> Unit)? = null): LinearLayout =
    row {
        setBackgroundColor(Theme.primary)
        setPadding(dp(8), dp(14), dp(16), dp(14))
        if (onBack != null) {
            text("‹", 28, true, Theme.onPrimary) {
                setPadding(dp(8), 0, dp(16), 0)
                setOnClickListener { onBack() }
            }
        }
        text(title, 20, true, Theme.onPrimary)
    }

// ---------- Diálogos e avisos ----------
fun Context.toast(msg: String) {
    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

fun Context.confirm(
    title: String,
    message: String,
    positive: String = "OK",
    onYes: () -> Unit
) {
    AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage(message)
        .setPositiveButton(positive) { _, _ -> onYes() }
        .setNegativeButton("Cancelar", null)
        .show()
}
