package com.example.notes.ui

import android.app.Activity
import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout

// =====================================================================
//  Telas e navegação (pilha simples)
// =====================================================================

abstract class Screen {
    lateinit var nav: Navigator
    val ctx: Context get() = nav.activity

    private val disposers = ArrayList<() -> Unit>()

    /** Monte a UI da tela aqui. Chamado toda vez que a tela aparece. */
    abstract fun build(): View

    fun render(): View {
        dispose()
        return build()
    }

    fun dispose() {
        for (d in disposers) d()
        disposers.clear()
    }

    /**
     * Reconstrói o bloco sempre que o [state] mudar.
     * Use dentro de build(): bind(Store.notes) { lista -> ... }
     */
    fun <T> ViewGroup.bind(state: State<T>, block: LinearLayout.(T) -> Unit): LinearLayout {
        val box = add(LinearLayout(context)) { orientation = LinearLayout.VERTICAL }
        disposers.add(state.observe { v ->
            box.removeAllViews()
            box.block(v)
        })
        return box
    }
}

class Navigator(val activity: Activity) {
    private val stack = ArrayList<Screen>()

    fun push(screen: Screen) {
        stack.lastOrNull()?.dispose()
        screen.nav = this
        stack.add(screen)
        show()
    }

    /** Volta uma tela. Retorna false se já está na primeira. */
    fun pop(): Boolean {
        if (stack.size <= 1) return false
        stack.removeAt(stack.size - 1).dispose()
        show()
        return true
    }

    private fun show() {
        activity.setContentView(stack.last().render())
    }
}
