package com.example.notes

import android.content.Context
import android.content.SharedPreferences
import com.example.notes.ui.State
import org.json.JSONArray
import org.json.JSONObject

data class Note(
    val id: Long,
    val title: String,
    val body: String = "",
    val done: Boolean = false
)

/** Dados do app, salvos em SharedPreferences (JSON). */
object Store {
    private lateinit var prefs: SharedPreferences

    val notes = State<List<Note>>(emptyList())

    fun setup(ctx: Context) {
        prefs = ctx.getSharedPreferences("notes", Context.MODE_PRIVATE)
        notes.value = load()
    }

    private fun load(): List<Note> {
        val arr = JSONArray(prefs.getString("data", "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Note(
                id = o.getLong("id"),
                title = o.getString("title"),
                body = o.optString("body", ""),
                done = o.optBoolean("done", false)
            )
        }
    }

    private fun save(list: List<Note>) {
        val arr = JSONArray()
        for (n in list) {
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("title", n.title)
                    .put("body", n.body)
                    .put("done", n.done)
            )
        }
        prefs.edit().putString("data", arr.toString()).apply()
        notes.value = list
    }

    fun add(title: String) = save(notes.value + Note(System.currentTimeMillis(), title))
    fun update(n: Note) = save(notes.value.map { if (it.id == n.id) n else it })
    fun delete(id: Long) = save(notes.value.filter { it.id != id })
}
