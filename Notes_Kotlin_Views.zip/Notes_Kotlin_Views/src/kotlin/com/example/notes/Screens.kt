package com.example.notes

import android.graphics.Paint
import android.view.View
import android.view.ViewGroup
import com.example.notes.ui.ButtonKind
import com.example.notes.ui.Screen
import com.example.notes.ui.Theme
import com.example.notes.ui.button
import com.example.notes.ui.checkbox
import com.example.notes.ui.confirm
import com.example.notes.ui.content
import com.example.notes.ui.divider
import com.example.notes.ui.dp
import com.example.notes.ui.input
import com.example.notes.ui.margin
import com.example.notes.ui.page
import com.example.notes.ui.row
import com.example.notes.ui.scroll
import com.example.notes.ui.spacer
import com.example.notes.ui.text
import com.example.notes.ui.toast
import com.example.notes.ui.topBar
import com.example.notes.ui.weight

// =====================================================================
//  Tela 1: lista de notas
// =====================================================================
class HomeScreen : Screen() {

    override fun build(): View = ctx.page {
        topBar("Notas")

        content {
            var draft = ""

            row {
                val field = input("Nova nota") { draft = it }
                field.weight(1f)
                button("Adicionar") {
                    if (draft.isBlank()) {
                        ctx.toast("Digite um título")
                    } else {
                        Store.add(draft.trim())
                        draft = ""
                        field.setText("")
                    }
                }.margin(l = 8)
            }

            spacer(8)

            scroll {
                bind(Store.notes) { notes ->
                    if (notes.isEmpty()) {
                        text("Nenhuma nota ainda.", color = Theme.textSecondary) {
                            setPadding(0, dp(16), 0, 0)
                        }
                    }
                    for (n in notes) noteRow(n)
                }
            }
        }
    }

    private fun ViewGroup.noteRow(n: Note) {
        row {
            setPadding(0, dp(6), 0, dp(6))

            checkbox("", n.done) { Store.update(n.copy(done = it)) }

            text(n.title, 18, color = if (n.done) Theme.textSecondary else Theme.text) {
                weight(1f)
                if (n.done) paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                setOnClickListener { nav.push(DetailScreen(n.id)) }
                setOnLongClickListener {
                    ctx.confirm("Excluir", "Excluir \"${n.title}\"?", "Excluir") {
                        Store.delete(n.id)
                    }
                    true
                }
            }
        }
        divider()
    }
}

// =====================================================================
//  Tela 2: editar uma nota
// =====================================================================
class DetailScreen(private val noteId: Long) : Screen() {

    override fun build(): View = ctx.page {
        topBar("Editar nota") { nav.pop() }

        content {
            val note = Store.notes.value.firstOrNull { it.id == noteId }
            if (note == null) {
                text("Nota não encontrada.")
                return@content
            }

            var newTitle = note.title
            var newBody = note.body
            var newDone = note.done

            input("Título", note.title) { newTitle = it }
            spacer(8)
            input("Conteúdo", note.body, multiline = true) { newBody = it }
            spacer(8)
            checkbox("Concluída", note.done) { newDone = it }
            spacer(16)

            row {
                button("Salvar") {
                    Store.update(
                        note.copy(
                            title = newTitle.ifBlank { note.title },
                            body = newBody,
                            done = newDone
                        )
                    )
                    nav.pop()
                }.weight(1f)

                button("Excluir", ButtonKind.Danger) {
                    ctx.confirm("Excluir nota", "Esta ação não pode ser desfeita.", "Excluir") {
                        Store.delete(noteId)
                        nav.pop()
                    }
                }.margin(l = 8)
            }
        }
    }
}
