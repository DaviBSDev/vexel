# Notes — template Kotlin + Views nativas (Vexel)

    vexel build

Estrutura:
- `src/kotlin/.../ui/Ui.kt`   mini DSL (page, row, text, input, button, checkbox, scroll, topBar, confirm, toast)
- `src/kotlin/.../ui/Nav.kt`  Screen + Navigator (pilha) + bind(state)
- `src/kotlin/.../Store.kt`   dados (SharedPreferences + JSON)
- `src/kotlin/.../Screens.kt` telas de exemplo (lista e edição)
- `src/AndroidManifest.xml`   tema Material do sistema, sem AndroidX

Nova tela: crie `class MinhaTela : Screen() { override fun build() = ctx.page { ... } }`
e abra com `nav.push(MinhaTela())`. Voltar: `nav.pop()` (o botão Voltar já chama).
Trocar cores: objeto `Theme` em Ui.kt.
Para trocar o nome do pacote, altere `package` no vexel.build e as pastas/`package` do Kotlin.
