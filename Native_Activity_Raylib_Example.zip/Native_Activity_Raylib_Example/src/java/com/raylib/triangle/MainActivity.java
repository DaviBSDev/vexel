package com.raylib.example;

import android.app.NativeActivity;

// NativeActivity carrega libnative.so (meta-data android.app.lib_name)
// e chama ANativeActivity_onCreate -> android_main (raylib) -> main().
public class MainActivity extends NativeActivity {
    static {
        System.loadLibrary("native");
    }
}
