#include "raylib.h"

#define RAYGUI_IMPLEMENTATION
#include "raygui.h"

// InitWindow(0, 0, ...) = resolução real da tela. Importante no Android:
// assim a posição do toque coincide com o que é desenhado.
int main(void) {
  InitWindow(0, 0, "raylib + raygui");
  SetTargetFPS(60);

  int clicks = 0;
  bool check = false;
  float slider = 50.0f;

  while (!WindowShouldClose()) {
    int w = GetScreenWidth();
    int h = GetScreenHeight();
    int base = (w < h) ? w : h; // menor lado da tela
    int u = base / 12;          // unidade de layout

    // UI escalada para telas de celular
    GuiSetStyle(DEFAULT, TEXT_SIZE, base / 22);

    float x = u;
    float bw = w - 2 * u; // largura dos controles

    BeginDrawing();
    ClearBackground(RAYWHITE);

    DrawText("raylib + raygui (toque)", (int)x, u / 2, base / 18, DARKGRAY);

    if (GuiButton((Rectangle){x, u * 2.0f, bw, u * 1.5f}, "Toque aqui"))
      clicks++;
    DrawText(TextFormat("Cliques: %d", clicks), (int)x, (int)(u * 3.8f),
             base / 22, DARKGRAY);

    GuiCheckBox((Rectangle){x, u * 4.8f, u, u}, "Checkbox", &check);

    GuiSlider((Rectangle){x + u * 1.5f, u * 6.2f, bw - u * 3.0f, u}, "0", "100",
              &slider, 0, 100);
    DrawText(TextFormat("Slider: %.0f", slider), (int)x, (int)(u * 7.4f),
             base / 22, DARKGRAY);

    // Debug de toque: círculo em cada dedo + contagem
    int touches = GetTouchPointCount();
    DrawText(TextFormat("Toques: %d", touches), (int)x, (int)(u * 8.4f),
             base / 22, MAROON);
    for (int i = 0; i < touches; i++)
      DrawCircleV(GetTouchPosition(i), base / 14.0f, Fade(RED, 0.5f));
    EndDrawing();
  }

  CloseWindow();
  return 0;
}
